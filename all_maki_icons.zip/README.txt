This download from mapbox.com/maki-icons/ includes the following:

1. LICENSE.txt.
2. A directory of all your styled icons in svgs/. These icons can be used for any purpose, but the tool was primarily designed to be used with mapbox.com/studio/styles/. Open a style and drag the contents of "svgs" onto the style.
3. an iconset-.js file. Use this file to import your iconset back into the maki icon editor at mapbox.com/maki-icons/#editable.